const { DynamoDBClient, PutItemCommand } = require("@aws-sdk/client-dynamodb");


exports.handler = async function CreateTable(event,context,callback){
  
  let region = event.region;
  let customerName = event.customerName;
  let customerPassword = event.customerPassword;
  let customerEmail = event.customerEmail;
  let customerIdentification = event.customerIdentification;
  let customerData = [];
  
  const response = await CreateUser(region,customerName,customerPassword,customerEmail,customerIdentification,customerData);

  return response;
}

async function CreateUser(region,customerName,customerPassword,customerEmail,customerIdentification,customerData){
  
  if(!(validateEntry(customerName,'String') && validateEntry(customerPassword,'String') && validateEntry(customerEmail,'String')
    && validateEntry(customerIdentification,'String'))){
    let response = HandlerClientError();
    return response;
  }

  const client = new DynamoDBClient({ region: region});

  
  var params = {
    TableName: 'CUSTOMER_LIST',
    Item: {
      'CUSTOMER_NAME' : {S: customerName},
      'CUSTOMER_PASSWORD' : {S: customerPassword},
      'CUSTOMER_EMAIL': {S:customerEmail},
      'CUSTOMER_IDENTIFICATION': {S:customerIdentification},
      'CUSTOMER_DATA': {L:customerData}
    }
  };
  
  const command = new PutItemCommand(params);

  try {
    const response = await client.send(command);
    let responseMessage = {
      "Code": response.$metadata.httpStatusCode
    }
    return responseMessage;
  }catch(error){
    let response = handlingError(error);
    return response;
  }
}

function handlingError(error){
  const ClientError = [
    'ConditionalCheckFailedException',
    'ItemCollectionSizeLimitExceededException',
    'LimitExceededException',
    'MissingAuthenticationTokenException',
    'ResourceInUseException',
    'ResourceNotFoundException',
    'UnrecognizedClientException',
    'ValidationException',
    'ProvisionedThroughputExceeded',
    'ProvisionedThroughputExceededException',
    'RequestLimitExceeded',
    'ThrottlingException',
  ]
  if(ClientError.includes(error.name)){
    let response = {
      "name": error.name,
      "message": error.message,
      "error": {
        "errorCode": error.$metadata.httpStatusCode
      }
    }
    return response;
  }
  if(error.name && error.message){
    let response = {
      "name": error.name,
      "message": error.message,
      "error": {
        "errorCode": 500
      }
    }
    return response;
  }
  let response = {
    "name": 'Unknown error',
    "message": 'unknown error at the moment of making the request',
    "error":{
      "errorCode": '500'
    }
  }
  return response;
}

function validateEntry(entry,dataType){
  if(entry == null || entry == ""){
    return false
  }
  switch (dataType){
    case 'String':
      if(typeof entry === "string")
        return true
        return false
    case 'Integer':
      if(typeof entry === "number")
        return true
        return false
  }
  return false;
}

function HandlerClientError(){
  let response = {
    "name": 'BAD_REQUEST',
    "message": 'Petition does not have the correct structure',
    "error": {
      "errorCode": 400,
    }
  }
  return response;
}