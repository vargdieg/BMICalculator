const { DynamoDBClient, UpdateItemCommand } = require("@aws-sdk/client-dynamodb");

exports.handler = async function CreateTable(event,context,callback){
  
  let region = event.region;
  let id = event.id;
  let FieldToChange = event.fieldToChange;
  let newValue = event.newValue;

  const response = await editTable(region,id,FieldToChange,newValue);
  return response;
}

async function editTable(region,id,FieldToChange,newValue){
  let response = "";
  switch (FieldToChange){
    case 'CUSTOMER_EMAIL':
        response = await updateEntry (region,id,FieldToChange,newValue,'String');
        return response;
    case 'CUSTOMER_NAME':
        response = await updateEntry (region,id,FieldToChange,newValue,'String');
        return response;
    case 'CUSTOMER_PASSWORD':
        response = await updateEntry (region,id,FieldToChange,newValue,'String');
        return response;
    default:
      response = {
        "name": 'Error desconocido',
        "message": 'Ocurrio un error inesperado al momento de realizar la peticion',
        "error":{
          "errorCode": '500'
        }
      }
      return response;
  }

}

async function updateEntry (region,id,entryToUpdate,value,datatype){
    
    if(!(validateEntry(value,datatype))){
        let response = HandlerClientError();
        return response;
    }
      
    const client = new DynamoDBClient({ region: region});

    var params = {
        ExpressionAttributeNames: {
         "#LD": entryToUpdate
        }, 
        ExpressionAttributeValues: {
         ":d": {
           S: value
          }
        }, 
        Key: {
            'CUSTOMER_IDENTIFICATION': {S:id},
        }, 
        ReturnValues: "ALL_NEW", 
        TableName: "CUSTOMER_LIST", 
        UpdateExpression: "SET #LD = :d"
       };

       const command = new UpdateItemCommand(params);
       try {
         const response = await client.send(command);
         let responseMessage = {
           "Code": response.$metadata.httpStatusCode
         }
         return responseMessage;
       }catch(error){
         let response = handlingError(error);
         return response;
       }
}

function handlingError(error){
  const ClientError = [
    'ConditionalCheckFailedException',
    'ItemCollectionSizeLimitExceededException',
    'LimitExceededException',
    'MissingAuthenticationTokenException',
    'ResourceInUseException',
    'ResourceNotFoundException',
    'UnrecognizedClientException',
    'ValidationException',
    'ProvisionedThroughputExceeded',
    'ProvisionedThroughputExceededException',
    'RequestLimitExceeded',
    'ThrottlingException',
  ]
  if(ClientError.includes(error.name)){
    let response = {
      "name": error.name,
      "message": error.message,
      "error": {
        "errorCode": error.$metadata.httpStatusCode
      }
    }
    return response;
  }
  if(error.name && error.message){
    let response = {
      "name": error.name,
      "message": error.message,
      "error": {
        "errorCode": 500
      }
    }
    return response;
  }
  let response = {
    "name": 'Unknown error',
    "message": 'unknown error at the moment of making the request',
    "error":{
      "errorCode": '500'
    }
  }
  return response;
}

function validateEntry(entry,dataType){
  if(entry == null || entry == ""){
    return false
  }
  switch (dataType){
    case 'String':
      if(typeof entry === "string")
        return true
        return false
    case 'Integer':
      if(typeof entry === "number")
        return true
        return false
  }
  return false;
}

function HandlerClientError(){
  let response = {
    "name": 'BAD_REQUEST',
    "message": 'Petition does not have the correct structure',
    "error": {
      "errorCode": 400,
    }
  }
  return response;
}