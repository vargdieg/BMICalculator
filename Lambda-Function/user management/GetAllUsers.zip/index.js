const { DynamoDBClient, ScanCommand} = require("@aws-sdk/client-dynamodb");

exports.handler = async function CreateTable(event,context,callback){
  let region = event.region;
  const response = await GetAllUserInfo(region);
  return response;
}

async function GetAllUserInfo(region){

  const client = new DynamoDBClient({ region: region});

  var params = {
    TableName: 'CUSTOMER_LIST',
    AttributesToGet: [
      "CUSTOMER_IDENTIFICATION","CUSTOMER_EMAIL","CUSTOMER_NAME"
    ]
  };

  const command = new ScanCommand(params);
    try {
      const response = await client.send(command);
      console.log(response);
      let Items = [];
      response.Items.forEach(element => {
        let mail = element.CUSTOMER_EMAIL.S;
        let id = element.CUSTOMER_IDENTIFICATION.S;
        let name = element.CUSTOMER_NAME.S;
        let entry = {
          CUSTOMER_NAME: name,
          CUSTOMER_EMAIL: mail,
          CUSTOMER_IDENTIFICATION: id
        };
        Items.push(entry);
      })
      let responseMessage = {
        "Code": response.$metadata.httpStatusCode,
        "Item": Items
      }
      return responseMessage;
    }catch(error){
      let response = handlingError(error);
      return response;
    }
}

function handlingError(error){
  const ClientError = [
    'ConditionalCheckFailedException',
    'ItemCollectionSizeLimitExceededException',
    'LimitExceededException',
    'MissingAuthenticationTokenException',
    'ResourceInUseException',
    'ResourceNotFoundException',
    'UnrecognizedClientException',
    'ValidationException',
    'ProvisionedThroughputExceeded',
    'ProvisionedThroughputExceededException',
    'RequestLimitExceeded',
    'ThrottlingException',
  ]
  if(ClientError.includes(error.name)){
    let response = {
      "name": error.name,
      "message": error.message,
      "error": {
        "errorCode": error.$metadata.httpStatusCode
      }
    }
    return response;
  }
  if(error.name && error.message){
    let response = {
      "name": error.name,
      "message": error.message,
      "error": {
        "errorCode": 500
      }
    }
    return response;
  }
  let response = {
    "name": 'Unknown error',
    "message": 'unknown error at the moment of making the request',
    "error":{
      "errorCode": '500'
    }
  }
  return response;
}

function validateEntry(entry,dataType){
  if(entry == null || entry == ""){
    return false
  }
  switch (dataType){
    case 'String':
      if(typeof entry === "string")
        return true
        return false
    case 'Integer':
      if(typeof entry === "number")
        return true
        return false
  }
  return false;
}

function HandlerClientError(){
  let response = {
    "name": 'BAD_REQUEST',
    "message": 'Petition does not have the correct structure',
    "error": {
      "errorCode": 400,
    }
  }
  return response;
}