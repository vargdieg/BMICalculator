const { DynamoDBClient, GetItemCommand } = require("@aws-sdk/client-dynamodb");



exports.handler = async function CreateTable(event,context,callback){
  let region = event.region;
  let id = event.id;
  const response = await GetUserInfo(region,id);
  return response;
}

async function GetUserInfo(region,id){
  if(!(validateEntry(id,'String'))){
    let response = HandlerClientError();
    return response;
  }
  
  const client = new DynamoDBClient({ region: region});

  var params = {
    TableName: 'CUSTOMER_LIST',
    Key: {
      'CUSTOMER_IDENTIFICATION': {S:id}
    }
  };
  
  const command = new GetItemCommand(params);
    try {
      const response = await client.send(command);
      if(response.Item == null){
        let responseMessage = {
          "name": 'NOT_FOUND',
          "message": 'user not found',
          "error": {
            "errorCode": 404,
          }
        }
        return responseMessage;
      }else{
      let responseMessage = {
        "Code": response.$metadata.httpStatusCode,
        "Item": {
          "CUSTOMER_NAME": response.Item.CUSTOMER_NAME.S,
          "CUSTOMER_EMAIL": response.Item.CUSTOMER_EMAIL.S,
          "CUSTOMER_IDENTIFICATION": response.Item.CUSTOMER_IDENTIFICATION.S,
          "CUSTOMER_PASSWORD": response.Item.CUSTOMER_PASSWORD.S,
        }
      }
      return responseMessage;
    }
    }catch(error){
      let response = handlingError(error);
      return response;
    }
}

function handlingError(error){
  const ClientError = [
    'ConditionalCheckFailedException',
    'ItemCollectionSizeLimitExceededException',
    'LimitExceededException',
    'MissingAuthenticationTokenException',
    'ResourceInUseException',
    'ResourceNotFoundException',
    'UnrecognizedClientException',
    'ValidationException',
    'ProvisionedThroughputExceeded',
    'ProvisionedThroughputExceededException',
    'RequestLimitExceeded',
    'ThrottlingException',
  ]
  if(ClientError.includes(error.name)){
    let response = {
      "name": error.name,
      "message": error.message,
      "error": {
        "errorCode": error.$metadata.httpStatusCode
      }
    }
    return response;
  }
  if(error.name && error.message){
    let response = {
      "name": error.name,
      "message": error.message,
      "error": {
        "errorCode": 500
      }
    }
    return response;
  }
  let response = {
    "name": 'Unknown error',
    "message": 'unknown error at the moment of making the request',
    "error":{
      "errorCode": '500'
    }
  }
  return response;
}

function validateEntry(entry,dataType){
  if(entry == null || entry == ""){
    return false
  }
  switch (dataType){
    case 'String':
      if(typeof entry === "string")
        return true
        return false
    case 'Integer':
      if(typeof entry === "number")
        return true
        return false
  }
  return false;
}

function HandlerClientError(){
  let response = {
    "name": 'BAD_REQUEST',
    "message": 'Petition does not have the correct structure',
    "error": {
      "errorCode": 400,
    }
  }
  return response;
}