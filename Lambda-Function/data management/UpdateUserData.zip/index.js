const { DynamoDBClient, UpdateItemCommand } = require("@aws-sdk/client-dynamodb");

exports.handler = async function updateUserData(event,context,callback){
  let region = event.region;
  let customerIdentification = event.id;
  let CustomData = event.data;
  let customerData = createDataArray(CustomData);
  let waist = event.waist;
  const response = await UpdateUserData(region,customerIdentification,customerData,waist);
  return response;
}



function createDataObject({weight,height,date,bmi,id,waist}){
  let object ={ 
    M : {
    weight: {N:""+weight},
    height: {N:""+height},
    date: {S:""+date},
    bmi: {N:""+bmi},
    id: {S:""+id},
    waist: {N: ""+waist}
  }
}
  return object;
}

function createDataArray(array){
    let CustomerData = [];
    array.forEach(element => {
        CustomerData.push(createDataObject(element));
      });
    return CustomerData;
}

async function UpdateUserData(region,customerIdentification,customerData){
  
  const client = new DynamoDBClient({ region: region});
  
  var params = {
      ExpressionAttributeNames: {
       "#LD": "CUSTOMER_DATA"
      }, 
      ExpressionAttributeValues: {
       ":d": {
         L: customerData
        }
      }, 
      Key: {
          'CUSTOMER_IDENTIFICATION': {S:customerIdentification},
      }, 
      ReturnValues: "ALL_NEW", 
      TableName: "CUSTOMER_LIST", 
      UpdateExpression: "SET #LD = :d"
     };

     const command = new UpdateItemCommand(params);
     try {
       const response = await client.send(command);
       let responseMessage = {
         "Code": response.$metadata.httpStatusCode
       }
       return responseMessage;
     }catch(error){
       let response = handlingError(error);
       return response;
     }
}

function handlingError(error){
  const ClientError = [
    'ConditionalCheckFailedException',
    'ItemCollectionSizeLimitExceededException',
    'LimitExceededException',
    'MissingAuthenticationTokenException',
    'ResourceInUseException',
    'ResourceNotFoundException',
    'UnrecognizedClientException',
    'ValidationException',
    'ProvisionedThroughputExceeded',
    'ProvisionedThroughputExceededException',
    'RequestLimitExceeded',
    'ThrottlingException',
  ]
  if(ClientError.includes(error.name)){
    let response = {
      "name": error.name,
      "message": error.message,
      "error": {
        "errorCode": error.$metadata.httpStatusCode
      }
    }
    return response;
  }
  if(error.name && error.message){
    let response = {
      "name": error.name,
      "message": error.message,
      "error": {
        "errorCode": 500
      }
    }
    return response;
  }
  let response = {
    "name": 'Unknown error',
    "message": 'unknown error at the moment of making the request',
    "error":{
      "errorCode": '500'
    }
  }
  return response;
}

function validateEntry(entry,dataType){
  if(entry == null || entry == ""){
    return false
  }
  switch (dataType){
    case 'String':
      if(typeof entry === "string")
        return true
        return false
    case 'Integer':
      if(typeof entry === "number")
        return true
        return false
  }
  return false;
}

function HandlerClientError(){
  let response = {
    "name": 'BAD_REQUEST',
    "message": 'Petition does not have the correct structure',
    "error": {
      "errorCode": 400,
    }
  }
  return response;
}