const { DynamoDBClient, PutItemCommand } = require("@aws-sdk/client-dynamodb");

exports.handler = async function CreateTable(event,context,callback){
  let region = event.region;
  let customerName = event.customerName;
  let customerOpinion = event.customerOpinion;
  let messageIdentifier = event.messageIdentifier;
  const response = await PutOpinion(region,customerName,customerOpinion,messageIdentifier);
  return response;
}

async function PutOpinion(region,customerName,customerOpinion,messageIdentifier){

  if(!(validateEntry(customerName,'String') && validateEntry(customerOpinion,'String') && validateEntry(messageIdentifier,'String'))){
      let response = HandlerClientError();
      return response;
  }

  const client = new DynamoDBClient({ region: region});

  var params = {
    TableName: 'CUSTOMER_OPINION_LIST',
    Item: {
      'CUSTOMER_NAME' : {S: ""+customerName},
      'CUSTOMER_OPINION' : {S: ""+customerOpinion},
      'MESSAGE_IDENTIFIER': {S:""+messageIdentifier}
    }
  };
  const command = new PutItemCommand(params);

  try {
    const response = await client.send(command);
    let responseMessage = {
      "Code": response.$metadata.httpStatusCode
    }
    return responseMessage;
  }catch(error){
    let response = handlingError(error);
    return response;
  }
}

function handlingError(error){
  const ClientError = [
    'ConditionalCheckFailedException',
    'ItemCollectionSizeLimitExceededException',
    'LimitExceededException',
    'MissingAuthenticationTokenException',
    'ResourceInUseException',
    'ResourceNotFoundException',
    'UnrecognizedClientException',
    'ValidationException',
    'ProvisionedThroughputExceeded',
    'ProvisionedThroughputExceededException',
    'RequestLimitExceeded',
    'ThrottlingException',
  ]
  if(ClientError.includes(error.name)){
    let response = {
      "name": error.name,
      "message": error.message,
      "error": {
        "errorCode": error.$metadata.httpStatusCode
      }
    }
    return response;
  }
  if(error.name && error.message){
    let response = {
      "name": error.name,
      "message": error.message,
      "error": {
        "errorCode": 500
      }
    }
    return response;
  }
  let response = {
    "name": 'Unknown error',
    "message": 'unknown error at the moment of making the request',
    "error":{
      "errorCode": '500'
    }
  }
  return response;
}

function validateEntry(entry,dataType){
  if(entry == null || entry == ""){
    return false
  }
  switch (dataType){
    case 'String':
      if(typeof entry === "string")
        return true
        return false
    case 'Integer':
      if(typeof entry === "number")
        return true
        return false
  }
  return false;
}

function HandlerClientError(){
  let response = {
    "name": 'BAD_REQUEST',
    "message": 'Petition does not have the correct structure',
    "error": {
      "errorCode": 400,
    }
  }
  return response;
}